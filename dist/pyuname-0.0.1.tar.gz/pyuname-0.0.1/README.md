# uname_library
 this is a stupid python library to print uname
