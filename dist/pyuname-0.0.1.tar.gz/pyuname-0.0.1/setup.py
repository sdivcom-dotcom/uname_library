from setuptools import setup

setup(name='pyuname',
      version='0.0.1',
      description='This is a dumb library for uname',
      packages=['pyuname'],
      author_email='sdivcom@yandex.ru',
      zip_safe=False)